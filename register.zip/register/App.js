import React from 'react';
import { StyleSheet, Text, View,Button } from 'react-native';
import firebase from 'firebase';
import {Header,Spinner} from './src/components/common';
import LoginForm from './src/components/LoginForm';

export default class App extends React.Component {
  state={loggedIn:null};
  componentWillMount() {
        firebase.initializeApp({
        apiKey: 'AIzaSyC9rmw4I0hTFs0lH9dkLglpNGuAIHGN7Sc',
        authDomain: 'register-8a4c6.firebaseapp.com',
        databaseURL: 'https://register-8a4c6.firebaseio.com',
        projectId: 'register-8a4c6',
        storageBucket: 'register-8a4c6.appspot.com',
        messagingSenderId: '455368718460'
      });

      firebase.auth().onAuthStateChanged((user) => {
        if(user){
          this.setState({loggedIn:true});
        }
        else{
          this.setState({loggedIn:false});
        }
      });
  }

    renderContent(){
      switch(this.state.loggedIn){
        case true:
          return (
            <View style={styles.loginTextSection}>
              <Button
                title="Logout"
                color="red"
                onPress={()=> firebase.auth().signOut()}
                >
              </Button>
            </View>
          );
        case false:
          return <LoginForm/>;
        default:
          return <Spinner size="large"/>;
      }
    }

  render() {
    return (
      <View>
        <Header headerText="Login"/>
        {this.renderContent()}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  loginTextSection: {
      alignItems:'center',
      paddingTop:10,
   },
});
